# DATA_PIPELINE.md — Corpus + Chunking + Embedding

---

## Corpus Inventory

| Collection | Path | Docs | Size | Extracted? |
|---|---|---|---|---|
| IT Circulars | `incometax_circulars/` | 337 | 225 MB | No — run extractor |
| IT Notifications | `incometax_notifications/` | 1,778 | 675 MB | No — run extractor |
| RBI Circulars | `saarthi_data/pdfs/rbi/` | 24 | ~20 MB | Yes |
| Schemes | `saarthi_data/pdfs/schemes/` | 1 | ~1 MB | Yes |
| **Total** | | **2,140** | **~924 MB** | |

**No merging. No subsampling. All 2,140 docs processed individually.**

---

## Extraction Pipeline

```python
# Run once to extract all collections
python scraper.py --extract-only   # processes saarthi_data/
python extract_existing.py         # processes incometax_circulars/ + incometax_notifications/
```

Text saved as `.txt` files mirroring PDF directory structure.
Image-only PDFs: install OCR first.
```bash
sudo apt install poppler-utils tesseract-ocr
pip install pdf2image pytesseract
```

---

## Structure-Aware Chunking Strategy

**Not fixed-size. Clause-level chunking.**

### Why Clause-Level
IT circulars structure: numbered clauses (1, 2, 3(a), 3(b)(i)).
Fixed-size chunks split mid-clause → incomplete obligations → bad retrieval.
Clause-level keeps each legal unit intact.

### Chunking Algorithm

```python
def chunk_document(text: str, doc_meta: dict) -> list[Chunk]:
    # Step 1: detect section boundaries
    # Patterns: "1.", "2.", "3(a)", "Clause 4", "Section 5", headings in ALL CAPS
    section_pattern = re.compile(
        r"(?m)^(?:\d+[\.\)]\s|\([a-z]\)\s|Clause\s\d+|Section\s\d+|[A-Z]{4,})"
    )

    # Step 2: split at boundaries
    splits = section_pattern.split(text)
    headers = section_pattern.findall(text)

    # Step 3: build chunks with overlap at section boundary only
    chunks = []
    for i, (header, body) in enumerate(zip(headers, splits[1:])):
        chunk_text = header + body.strip()

        # Merge tiny chunks (<100 chars) with next
        if len(chunk_text) < 100 and i + 1 < len(splits):
            continue

        # Split large chunks (>1500 chars) at paragraph boundary
        if len(chunk_text) > 1500:
            sub_chunks = split_at_paragraphs(chunk_text, max_size=1200)
        else:
            sub_chunks = [chunk_text]

        for j, sc in enumerate(sub_chunks):
            chunks.append(Chunk(
                text=sc,
                doc_id=doc_meta["doc_id"],
                section_id=f"{i}.{j}",
                clause_number=header.strip(),
                page_number=doc_meta.get("page_num", 0),
                doc_type=doc_meta["doc_type"],
                title=doc_meta["title"],
                date=doc_meta["date"],
                url=doc_meta["url"],
                circular_number=doc_meta.get("circular_number", ""),
            ))

    return chunks
```

### Chunk Size Targets

| Doc Type | Avg Chunk Size | Reason |
|---|---|---|
| IT Circular | 400-600 tokens | Short clauses, dense obligations |
| IT Notification | 300-500 tokens | Procedural, list-heavy |
| RBI Circular | 600-900 tokens | Long prudential norm paragraphs |
| Scheme Doc | 500-800 tokens | Mixed prose + tables |

---

## Embedding

**Model: `BAAI/bge-large-en-v1.5`**

Why BGE over generic sentence-transformers:
- Trained on retrieval tasks — better than all-MiniLM for domain-specific docs
- 1024-dim embeddings — richer representation for legal text
- Instruction prefix: `"Represent this sentence for searching relevant passages: "`

```python
from sentence_transformers import SentenceTransformer

embedder = SentenceTransformer("BAAI/bge-large-en-v1.5")

def embed_chunk(text: str) -> list[float]:
    prefix = "Represent this sentence for searching relevant passages: "
    return embedder.encode(prefix + text).tolist()
```

---

## ChromaDB Storage

```python
import chromadb

client     = chromadb.PersistentClient(path="./chroma_store")
collection = client.get_or_create_collection(
    name="saarthi_corpus",
    metadata={"hnsw:space": "cosine"}
)

# Ingestion
collection.add(
    ids=[chunk.chunk_id],
    embeddings=[chunk.embedding],
    documents=[chunk.text],
    metadatas=[{
        "doc_id":          chunk.doc_id,
        "doc_type":        chunk.doc_type,       # filter by type
        "title":           chunk.title,
        "date":            chunk.date,
        "url":             chunk.url,
        "circular_number": chunk.circular_number,
        "clause_number":   chunk.clause_number,
        "section_id":      chunk.section_id,
    }]
)

# Query
results = collection.query(
    query_embeddings=[query_embedding],
    n_results=10,
    where={"doc_type": "IT_CIRCULAR"},  # optional filter
    include=["documents", "metadatas", "distances"]
)
```

---

## BM25 Index

```python
from rank_bm25 import BM25Okapi

# Build once, persist as pickle
def build_bm25(chunks: list[Chunk]) -> BM25Okapi:
    tokenised = [c.text.lower().split() for c in chunks]
    return BM25Okapi(tokenised)

# Query
def bm25_search(index, chunk_list, query, top_k=10):
    scores = index.get_scores(query.lower().split())
    ranked = sorted(enumerate(scores), key=lambda x: -x[1])
    return [chunk_list[i] for i, _ in ranked[:top_k]]
```

---

## Estimated Corpus Scale After Full Ingestion

| Metric | Estimate |
|---|---|
| Total chunks | ~18,000-22,000 |
| Avg chunk size | ~450 tokens |
| ChromaDB size on disk | ~2-3 GB |
| BM25 index size | ~500 MB |
| Embedding time (CPU) | ~4-6 hours for full corpus |
| Embedding time (GPU) | ~30-45 min |

---

## Metadata Schema Per Chunk

```python
@dataclass
class Chunk:
    chunk_id:        str    # f"{doc_id}_{section_id}"
    doc_id:          str    # SHA256 of PDF content
    text:            str    # clause/section text
    embedding:       list[float]
    doc_type:        str    # IT_CIRCULAR / IT_NOTIFICATION / RBI / SCHEME
    title:           str    # e.g. "Circular No. 6 of 2024"
    date:            str    # ISO date string
    url:             str    # source URL
    circular_number: str    # e.g. "6/2024"
    clause_number:   str    # e.g. "3(b)(ii)"
    section_id:      str    # positional ID within doc
    page_number:     int
```
