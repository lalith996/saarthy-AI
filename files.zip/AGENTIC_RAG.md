# AGENTIC_RAG.md — Agent Loop + Web Search

---

## Why Agentic (Not Naive RAG)

Naive RAG: retrieve → generate. One shot. No quality check.

Agentic RAG: retrieve → evaluate sufficiency → conditionally search web → generate → verify grounding → respond.

LLM decides at each node whether to proceed or escalate. No hardcoded paths.

---

## LangGraph Graph Definition

```python
from langgraph.graph import StateGraph, END
from typing import TypedDict, Literal

class AgentState(TypedDict):
    query: str
    query_type: str
    query_entities: dict
    local_chunks: list
    web_results: list
    final_chunks: list
    retrieval_score: float
    web_search_triggered: bool
    llm_response: str
    grounding_score: float
    confidence_level: str
    citations: list
    action_steps: list
    error: str | None

# Graph wiring
graph = StateGraph(AgentState)

graph.add_node("query_analyser",    query_analyser_node)
graph.add_node("retriever",         retriever_node)
graph.add_node("confidence_eval",   confidence_eval_node)
graph.add_node("web_search",        web_search_node)
graph.add_node("generator",         generator_node)
graph.add_node("grounding_verify",  grounding_verify_node)
graph.add_node("formatter",         formatter_node)

graph.set_entry_point("query_analyser")

graph.add_edge("query_analyser",   "retriever")
graph.add_edge("retriever",        "confidence_eval")
graph.add_conditional_edges(
    "confidence_eval",
    route_after_eval,           # returns "web_search" or "generator"
    {"web_search": "web_search", "generator": "generator"}
)
graph.add_edge("web_search",       "generator")
graph.add_edge("generator",        "grounding_verify")
graph.add_edge("grounding_verify", "formatter")
graph.add_edge("formatter",        END)
```

---

## Node Implementations

### query_analyser_node
```python
def query_analyser_node(state: AgentState) -> AgentState:
    query = state["query"]

    # Classify query type
    query_type = classify_query(query)
    # classify_query: zero-shot with Mistral or rule-based
    # types: factual / procedural / eligibility / deadline / draft_request

    # Extract entities from query (reuse NER model)
    entities = ner_model(query)
    # e.g. {"deadline": "March 31", "section": "80C", "year": "2024"}

    return {**state,
            "query_type": query_type,
            "query_entities": entities}
```

### retriever_node
```python
def retriever_node(state: AgentState) -> AgentState:
    query   = state["query"]
    q_embed = embedder.encode(
        "Represent this sentence for searching relevant passages: " + query
    ).tolist()

    # Dense retrieval
    dense = chroma_collection.query(
        query_embeddings=[q_embed],
        n_results=10,
        include=["documents", "metadatas", "distances"]
    )

    # Sparse retrieval
    sparse = bm25_search(bm25_index, all_chunks, query, top_k=10)

    # RRF fusion
    final = rrf_merge(dense_results=dense, sparse_results=sparse, top_k=5)

    # Avg cosine similarity as retrieval score
    score = float(np.mean([1 - d for d in dense["distances"][0][:5]]))

    return {**state,
            "local_chunks": final,
            "retrieval_score": score}
```

### confidence_eval_node + router
```python
def confidence_eval_node(state: AgentState) -> AgentState:
    # Score already computed in retriever
    # Additional check: do chunks actually contain query entities?
    entity_overlap = compute_entity_overlap(
        state["query_entities"],
        state["local_chunks"]
    )
    adjusted_score = 0.7 * state["retrieval_score"] + 0.3 * entity_overlap
    return {**state, "retrieval_score": adjusted_score}

def route_after_eval(state: AgentState) -> Literal["web_search", "generator"]:
    if state["retrieval_score"] < 0.65:
        return "web_search"
    return "generator"
```

### web_search_node
```python
from tavily import TavilyClient

tavily = TavilyClient(api_key=config.TAVILY_API_KEY)

DOMAIN_WHITELIST = [
    "incometaxindia.gov.in", "incometax.gov.in",
    "cbdt.gov.in", "rbi.org.in", "rbidocs.rbi.org.in",
    "myscheme.gov.in", "india.gov.in",
]

def web_search_node(state: AgentState) -> AgentState:
    query = state["query"]

    # Build domain-restricted query
    site_filter = " OR ".join(f"site:{d}" for d in DOMAIN_WHITELIST[:4])
    search_query = f"{query} {site_filter}"

    try:
        results = tavily.search(
            query=search_query,
            max_results=5,
            include_raw_content=True,
            search_depth="advanced"
        )
        web_chunks = [
            {
                "text":   r["content"][:1500],
                "url":    r["url"],
                "title":  r["title"],
                "source": "web_search",
                "date":   r.get("published_date", ""),
            }
            for r in results.get("results", [])
        ]
    except Exception as e:
        log.error(f"Tavily search failed: {e}")
        web_chunks = []

    # Merge local + web, re-rank by relevance
    merged = merge_and_rerank(state["local_chunks"], web_chunks, query)

    return {**state,
            "web_results": web_chunks,
            "final_chunks": merged,
            "web_search_triggered": True}
```

### generator_node
```python
SYSTEM_PROMPT = """You are Saarthi, an AI assistant helping Indian citizens understand government documents.

Rules:
- Answer ONLY from the provided context chunks.
- If context insufficient, say so explicitly — do not hallucinate.
- Always cite the source circular/notification number and date.
- For deadlines: state exact date and consequence of missing it.
- For penalties: state exact amount and triggering condition.
- Use simple, plain English — target a Class 10 reading level.
- Format: Answer → Key Facts (bullet) → Action Steps (numbered) → Sources (cited)
"""

def generator_node(state: AgentState) -> AgentState:
    chunks = state.get("final_chunks") or state["local_chunks"]

    context = "\n\n---\n\n".join([
        f"[Source: {c.get('title','Unknown')} | {c.get('date','')} | {c.get('url','')}]\n{c['text']}"
        for c in chunks
    ])

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user",   "content": f"Context:\n{context}\n\nQuestion: {state['query']}"}
    ]

    response = ollama_client.chat(
        model="mistral:7b-instruct",
        messages=messages
    )

    return {**state, "llm_response": response["message"]["content"]}
```

### grounding_verify_node
```python
def grounding_verify_node(state: AgentState) -> AgentState:
    answer = state["llm_response"]
    chunks = state.get("final_chunks") or state["local_chunks"]

    answer_emb = embedder.encode(answer)
    chunk_texts = [c["text"] for c in chunks]
    chunk_embs  = embedder.encode(chunk_texts)

    sims  = cosine_similarity([answer_emb], chunk_embs)[0]
    score = float(np.max(sims))

    if score >= 0.75:   level = "HIGH"
    elif score >= 0.55: level = "MEDIUM"
    else:               level = "LOW"

    return {**state,
            "grounding_score":  score,
            "confidence_level": level}
```

### formatter_node
```python
def formatter_node(state: AgentState) -> AgentState:
    chunks = state.get("final_chunks") or state["local_chunks"]

    citations = [
        Citation(
            title=c.get("title", ""),
            circular_number=c.get("circular_number", ""),
            date=c.get("date", ""),
            url=c.get("url", ""),
            clause=c.get("clause_number", ""),
            source_type="web" if c.get("source") == "web_search" else "local"
        )
        for c in chunks
    ]

    return {**state, "citations": citations}
```

---

## Web Search Triggers (When Agent Uses Web)

| Condition | Example Query | Trigger |
|---|---|---|
| Low retrieval score < 0.65 | "Latest circular on TDS 2025" | Auto |
| Query contains current year not in corpus | "2025 ITR deadline" | Auto |
| User explicitly asks for latest | "What is the current rate for..." | Auto |
| Query about scheme not in corpus | "PM Surya Ghar scheme rules" | Auto |

---

## Fallback Chain

```
ChromaDB (dense) + BM25 (sparse)
    │ score < 0.65
    ▼
Tavily Web Search (govt domains only)
    │ no results / error
    ▼
Honest "I don't know" response
    │ never hallucinate
    ▼
Suggest user visit official portal + provide URL
```

---

## Prompt Templates Per Query Type

| Type | Prompt Focus |
|---|---|
| factual | "Extract the exact value/rule from context" |
| procedural | "List the steps in order with deadlines" |
| eligibility | "State the conditions. Does user qualify? What's missing?" |
| deadline | "State exact date, consequence of missing, how to comply" |
| draft_request | "Generate reply using extracted entities + template" |
