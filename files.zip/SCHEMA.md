# SCHEMA.md — Database + Vector Store Schema

---

## PostgreSQL Tables

### documents
```sql
CREATE TABLE documents (
    doc_id          TEXT PRIMARY KEY,          -- SHA256 of PDF content
    title           TEXT NOT NULL,
    doc_type        TEXT NOT NULL,             -- IT_CIRCULAR / IT_NOTIFICATION / RBI / SCHEME
    source          TEXT NOT NULL,             -- 'corpus' or 'user_upload'
    url             TEXT,
    date            DATE,
    circular_number TEXT,
    file_path       TEXT,
    text_path       TEXT,
    chunk_count     INT DEFAULT 0,
    char_count      INT DEFAULT 0,
    status          TEXT DEFAULT 'pending',    -- pending/extracted/embedded/failed
    ocr_used        BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### chunks
```sql
CREATE TABLE chunks (
    chunk_id        TEXT PRIMARY KEY,          -- f"{doc_id}_{section_id}"
    doc_id          TEXT REFERENCES documents(doc_id),
    text            TEXT NOT NULL,
    section_id      TEXT,
    clause_number   TEXT,
    page_number     INT,
    char_count      INT,
    embedded_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### entities
```sql
CREATE TABLE entities (
    id              SERIAL PRIMARY KEY,
    doc_id          TEXT REFERENCES documents(doc_id),
    entity_type     TEXT NOT NULL,             -- AUTHORITY/RECIPIENT/DEADLINE/AMOUNT/LEGAL_REF
    value           TEXT NOT NULL,
    clause_number   TEXT,
    confidence      FLOAT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### clauses
```sql
CREATE TABLE clauses (
    id              SERIAL PRIMARY KEY,
    doc_id          TEXT REFERENCES documents(doc_id),
    chunk_id        TEXT REFERENCES chunks(chunk_id),
    clause_number   TEXT,
    clause_type     TEXT NOT NULL,             -- OBLIGATION/PROHIBITION/ELIGIBILITY/PENALTY/INFORMATION
    text            TEXT NOT NULL,
    deadline        DATE,
    penalty_amount  TEXT,
    confidence      FLOAT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### query_logs
```sql
CREATE TABLE query_logs (
    id              SERIAL PRIMARY KEY,
    session_id      TEXT,
    query           TEXT NOT NULL,
    query_type      TEXT,
    doc_id          TEXT,                      -- null if corpus-wide
    web_used        BOOLEAN DEFAULT FALSE,
    retrieval_score FLOAT,
    grounding_score FLOAT,
    confidence      TEXT,                      -- HIGH/MEDIUM/LOW
    latency_ms      INT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### drafts
```sql
CREATE TABLE drafts (
    draft_id        TEXT PRIMARY KEY,          -- UUID
    doc_id          TEXT REFERENCES documents(doc_id),
    template_type   TEXT NOT NULL,
    content         TEXT NOT NULL,
    user_details    JSONB,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

---

## ChromaDB Collection Schema

**Collection name:** `saarthi_corpus`
**Distance metric:** cosine
**Embedding dim:** 1024 (BGE-large)

### Metadata Fields Per Document (Chunk)

```python
{
    # Identity
    "doc_id":          str,   # links to PostgreSQL documents table
    "chunk_id":        str,   # primary key

    # Document classification
    "doc_type":        str,   # IT_CIRCULAR / IT_NOTIFICATION / RBI / SCHEME
    "source":          str,   # corpus / user_upload

    # Citation fields (surfaced to user)
    "title":           str,   # "Circular No. 6 of 2024"
    "circular_number": str,   # "6/2024"
    "date":            str,   # ISO date "2024-04-15"
    "url":             str,   # original source URL

    # Position within doc (for re-ranking by position if needed)
    "clause_number":   str,   # "3(b)(ii)"
    "section_id":      str,   # "3.1"
    "page_number":     int,

    # Pre-computed labels (avoid re-inference at query time)
    "clause_type":     str,   # OBLIGATION/PENALTY/etc.
}
```

### Filterable Fields for Query
```python
# Filter by doc type
collection.query(where={"doc_type": "IT_CIRCULAR"})

# Filter by date range (ChromaDB uses $gte/$lte)
collection.query(where={"date": {"$gte": "2023-01-01"}})

# Filter by specific doc
collection.query(where={"doc_id": "abc123"})
```

---

## BM25 Index Persistence

```python
import pickle, pathlib

BM25_PATH = pathlib.Path("./bm25_index.pkl")

# Save
with open(BM25_PATH, "wb") as f:
    pickle.dump({"index": bm25_obj, "chunk_ids": chunk_id_list}, f)

# Load
with open(BM25_PATH, "rb") as f:
    data = pickle.load(f)
    bm25_obj     = data["index"]
    chunk_id_list = data["chunk_ids"]
```

---

## Entity Types

| Type | Examples | NER Label |
|---|---|---|
| AUTHORITY | "CBDT", "RBI", "Assessing Officer" | `AUTHORITY` |
| RECIPIENT | "All taxpayers", "employer", "deductor" | `RECIPIENT` |
| DEADLINE | "31 March 2024", "30 June 2024" | `DEADLINE` |
| MONETARY_AMOUNT | "₹10,000", "0.5%", "Rs. 5 lakh" | `AMOUNT` |
| LEGAL_REFERENCE | "Section 192", "Rule 31A", "Notification No. 41/2023" | `LEGAL_REF` |

## Clause Types

| Type | Signals |
|---|---|
| OBLIGATION | "shall", "must", "required to", "is obligated" |
| PROHIBITION | "shall not", "prohibited", "must not", "not permitted" |
| ELIGIBILITY | "eligible if", "qualified persons", "applicable to", "who can" |
| PENALTY | "penalty", "interest", "prosecution", "₹", "fine" |
| INFORMATION | everything else — definitions, explanations, context |
