# ARCHITECTURE.md — System Design

---

## High-Level Component Map

```
┌─────────────────────────────────────────────────────────────┐
│                        REACT FRONTEND                        │
│  [Upload View]  [Dashboard View]  [Chat + Draft View]        │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTP / WebSocket
┌────────────────────────▼────────────────────────────────────┐
│                      FASTAPI BACKEND                         │
│                                                              │
│  /upload  /analyse  /query  /draft  /search                 │
└──┬───────────────┬──────────────────┬───────────────────────┘
   │               │                  │
   ▼               ▼                  ▼
[Doc Pipeline] [LangGraph Agent]  [Draft Generator]
   │               │
   ▼               ├──► [ChromaDB]  dense retrieval
[PostgreSQL]       ├──► [BM25 Index] sparse retrieval
(doc registry)     ├──► [RRF Re-ranker]
                   ├──► [Grounding Verifier]
                   ├──► [Mistral-7B / Ollama]
                   └──► [Tavily Web Search] ← fallback
```

---

## Document Processing Pipeline

```
PDF Upload
    │
    ▼
pdfplumber extract
    │ < 100 chars?
    ▼
pytesseract OCR fallback
    │
    ▼
clean_text() — strip headers/footers/page numbers
    │
    ▼
Doc Type Classifier (logistic regression on TF-IDF)
    │ → IT_CIRCULAR / IT_NOTIFICATION / RBI / SCHEME
    ▼
Structure-Aware Chunker
    │ split at clause boundaries (regex + heading detection)
    │ each chunk: {text, section_id, clause_num, page_num, doc_id}
    ▼
NER Model (SpaCy custom)
    │ → Authority, Recipient, Deadline, Amount, Legal_Reference
    ▼
Clause Classifier (DistilBERT fine-tuned)
    │ → OBLIGATION / PROHIBITION / ELIGIBILITY / PENALTY / INFORMATION
    ▼
BGE Embedder — embed each chunk
    │
    ▼
ChromaDB — store chunk + metadata + embedding
    │
    ▼
BM25 Index — add chunk text to sparse index
```

---

## Agentic RAG Loop (LangGraph)

```
User Query
    │
    ▼
[Query Analyser Node]
    │ classify: factual / procedural / eligibility / deadline / draft
    │ extract named entities from query
    ▼
[Retriever Node]
    │ dense: ChromaDB top-10 by cosine similarity
    │ sparse: BM25 top-10 by BM25 score
    │ fuse: RRF re-ranking → top-5 final chunks
    ▼
[Confidence Evaluator Node]
    │ score = avg cosine sim of top-5 chunks
    │ if score > 0.75 → SUFFICIENT → go to Generator
    │ if score < 0.75 → INSUFFICIENT → go to Web Search
    ▼
[Web Search Node] (conditional)
    │ Tavily search: query + site: whitelist
    │ parse results → extract relevant text
    │ merge with local chunks → re-rank
    ▼
[Generator Node]
    │ prompt: system + retrieved chunks + query
    │ Mistral-7B generates structured answer
    │ format: answer + cited sources + action steps
    ▼
[Grounding Verifier Node]
    │ re-embed LLM answer
    │ cosine sim vs retrieved chunks
    │ if sim < 0.6 → flag LOW CONFIDENCE
    │ if sim > 0.6 → flag HIGH CONFIDENCE
    ▼
[Response Formatter Node]
    │ attach source citations (circular number, date, URL)
    │ attach confidence badge
    │ attach suggested next actions
    ▼
Final Response → Frontend
```

---

## LangGraph State Schema

```python
class AgentState(TypedDict):
    query: str
    query_type: str                    # factual/procedural/eligibility/deadline
    query_entities: dict               # NER on query
    local_chunks: list[ChunkResult]    # from ChromaDB + BM25
    web_results: list[WebResult]       # from Tavily (empty if not triggered)
    final_chunks: list[ChunkResult]    # after RRF fusion
    retrieval_score: float             # avg cosine sim
    web_search_triggered: bool
    llm_response: str
    grounding_score: float
    confidence_level: str              # HIGH / MEDIUM / LOW
    citations: list[Citation]
    action_steps: list[str]
```

---

## Web Search Domain Whitelist

```python
ALLOWED_DOMAINS = [
    "incometaxindia.gov.in",
    "incometax.gov.in",
    "cbdt.gov.in",
    "rbi.org.in",
    "rbidocs.rbi.org.in",
    "myscheme.gov.in",
    "india.gov.in",
    "pmkisan.gov.in",
    "nrega.nic.in",
    "pmjay.gov.in",
]

# Tavily query format:
# f"{user_query} site:incometaxindia.gov.in OR site:incometax.gov.in"
```

---

## Grounding Verifier Logic

```python
def verify_grounding(answer: str, chunks: list[str], embedder) -> float:
    answer_emb = embedder.encode(answer)
    chunk_embs = embedder.encode(chunks)
    sims = cosine_similarity([answer_emb], chunk_embs)[0]
    return float(np.max(sims))   # max sim to any chunk

# Thresholds:
# >= 0.75 → HIGH  (answer well-supported)
# 0.55-0.75 → MEDIUM (answer partially supported)
# < 0.55 → LOW  (flag as potentially hallucinated)
```

---

## RRF Re-Ranking

```python
def rrf_score(dense_rank: int, sparse_rank: int, k: int = 60) -> float:
    return 1/(k + dense_rank) + 1/(k + sparse_rank)

# Merge dense top-10 + sparse top-10 → score each → sort → take top-5
```

---

## Draft Generator

```
Extracted Entities (from NER on uploaded doc)
    │
    ▼
Template Selection (user picks or system suggests)
    │ templates: [reply_to_notice, appeal_letter, scheme_application,
    │             eligibility_inquiry, compliance_confirmation]
    ▼
LLM fills template slots
    │ prompt includes: template + entities + doc summary
    ▼
Editable text in UI → user modifies
    ▼
WeasyPrint → PDF export
```

---

## Docker Compose Services

```yaml
services:
  frontend:    # React, port 3000
  backend:     # FastAPI, port 8000
  ollama:      # Mistral-7B, port 11434
  chromadb:    # Vector store, port 8001
  postgres:    # Doc registry, port 5432
```
