# TEST_PLAN.md — Test Cases

---

## Unit Tests

### PDF Extraction
```
TEST: extract_text_pdfplumber
  IN:  valid digital PDF path
  OUT: string len > 100
  EDGE: corrupt PDF → returns ""  (no exception)
  EDGE: image-only PDF → len < 100 → triggers OCR fallback

TEST: is_pdf_content
  IN:  b"%PDF-1.4 rest"  → True
  IN:  b"<html>"         → False
  IN:  b"AB"             → False (too short)
  IN:  b""               → False

TEST: clean_text
  IN:  "text\n\n\n\nmore\x0cpage" → no \x0c, max 2 consecutive \n
  IN:  "123\n456\nReal text"      → page artifact lines removed
```

### Chunking
```
TEST: chunk_document
  IN:  IT circular with numbered clauses "1. ... 2. ... 3(a). ..."
  OUT: list[Chunk], each chunk contains exactly 1 clause boundary
  EDGE: chunk < 100 chars → merged with next
  EDGE: chunk > 1500 chars → split at paragraph

TEST: chunk metadata
  IN:  any valid doc
  OUT: every chunk has doc_id, clause_number, section_id, doc_type
  EDGE: missing metadata → defaults not None
```

### Topic Detection (merger.py)
```
TEST: detect_topic
  IN:  "TDS on Salary 192"    → "tds_salary"
  IN:  "Faceless Assessment"  → "e_proceedings"
  IN:  "80C PPF deduction"    → "deduction_80c"
  IN:  "unknown random doc"   → "general_notifications"
  EDGE: empty string → "general_notifications"
```

### RRF Re-ranking
```
TEST: rrf_score
  IN:  dense_rank=1, sparse_rank=1, k=60  → 2/61 ≈ 0.0328
  IN:  dense_rank=1, sparse_rank=10, k=60 → 1/61 + 1/70 ≈ 0.0307
  EDGE: rank=0 → use rank=1 (avoid division by near-zero)

TEST: rrf_merge
  IN:  dense top-10, sparse top-10 (some overlap)
  OUT: list of 5, no duplicates, sorted by rrf_score desc
```

### Grounding Verifier
```
TEST: verify_grounding
  IN:  answer same as chunk text → score > 0.90
  IN:  answer unrelated to chunks → score < 0.40
  OUT: float in [0, 1]
  EDGE: empty chunks → returns 0.0
```

### Slug / Utility
```
TEST: slug
  IN:  "Income Tax Circular No. 5/2024!" → "income_tax_circular_no_52024"
  IN:  ""  → "untitled"
  IN:  "x" * 100 → len == 60

TEST: has_pdf_extension
  IN:  "file.PDF"        → True   (uppercase fix)
  IN:  "file.pdf?v=1"   → True   (query string stripped)
  IN:  "file.html"      → False
```

---

## Integration Tests

### POST /upload
```
TEST: POST /upload valid PDF
  SETUP:  clean DB
  INPUT:  valid IT circular PDF
  EXPECT: 200, doc_id present, entities extracted, chunk_count > 0

TEST: POST /upload not-a-PDF
  INPUT:  .txt file renamed .pdf
  EXPECT: 422, error=NOT_A_PDF

TEST: POST /upload image-only PDF (no OCR installed)
  INPUT:  scanned PDF
  EXPECT: 200, status=low_content, warning in response

TEST: POST /upload duplicate
  SETUP:  same PDF already in DB
  EXPECT: 200, returns existing doc_id, no reprocessing
```

### POST /query
```
TEST: POST /query high-confidence local
  SETUP:  ChromaDB has IT circular chunks
  INPUT:  {query: "What is the TDS rate on salary?", allow_web: false}
  EXPECT: 200, confidence=HIGH, web_used=false, citations non-empty

TEST: POST /query low-confidence triggers web
  SETUP:  ChromaDB empty or unrelated
  INPUT:  {query: "2025 ITR filing deadline", allow_web: true}
  EXPECT: 200, web_used=true, citations contain source_type=web

TEST: POST /query web disabled
  INPUT:  {query: "2025 latest", allow_web: false}
  EXPECT: 200, web_used=false, confidence likely MEDIUM or LOW

TEST: POST /query doc-specific
  SETUP:  doc_id exists
  INPUT:  {query: "deadline?", doc_id: "abc123"}
  EXPECT: 200, all citations reference doc abc123

TEST: POST /query empty query
  INPUT:  {query: ""}
  EXPECT: 422 validation error
```

### POST /draft
```
TEST: POST /draft valid
  SETUP:  doc_id with extracted entities exists
  INPUT:  {doc_id, template_type: "reply_to_notice", user_details: {...}}
  EXPECT: 200, content non-empty, draft_id present

TEST: GET /draft/{id}/pdf
  SETUP:  draft exists
  EXPECT: 200, Content-Type: application/pdf, body starts with %PDF

TEST: POST /draft unknown template
  INPUT:  {template_type: "nonexistent"}
  EXPECT: 422
```

### Agent Loop
```
TEST: full agent loop high-confidence
  IN:  query with strong local match
  OUT: web_search_triggered=False, grounding_score > 0.75

TEST: full agent loop low-confidence → web fallback
  IN:  query about 2025 data not in corpus
  OUT: web_search_triggered=True, web_results non-empty

TEST: agent loop Tavily failure
  SETUP:  mock Tavily to throw exception
  OUT:    graceful degradation, answer from local only, no crash
```

---

## E2E Tests (Playwright)

### Upload + Analyse Flow
```
FLOW: citizen uploads income tax notice
  GIVEN: app loaded, empty state
  WHEN:  user drags PDF onto upload zone
         loading spinner appears
         processing completes
  THEN:  document dashboard shows
         entity cards visible (Deadline, Penalty, Authority)
         action plan numbered list visible
         no console errors
```

### Q&A Flow
```
FLOW: user asks question, gets cited answer
  GIVEN: document already uploaded (doc_id in state)
  WHEN:  user types "What happens if I miss the deadline?"
         presses Enter
  THEN:  answer appears within 15 seconds
         confidence badge visible (HIGH/MEDIUM/LOW)
         at least 1 citation card shown with circular number
         source clause text visible in citation
```

### Web Search Fallback Flow
```
FLOW: query triggers web search
  GIVEN: query about very recent data (2025)
  WHEN:  user asks "What is the ITR deadline for 2025?"
  THEN:  "Searching web..." indicator appears
         answer includes web citation with gov.in URL
         "Source: Web" badge visible
```

### Draft Generation Flow
```
FLOW: user generates reply to notice
  GIVEN: IT notice uploaded and analysed
  WHEN:  user clicks "Generate Draft Reply"
         fills name + PAN in form
         clicks "Generate"
  THEN:  draft text appears in editable textarea
         user edits one line
         clicks "Export PDF"
         browser downloads .pdf file
         PDF opens and contains user's name
```

---

## Regression Checklist

- [ ] Upload same PDF twice → no duplicate in DB
- [ ] Query with `allow_web: false` → Tavily never called
- [ ] LLM timeout → 500 error with `LLM_TIMEOUT` code, not hang
- [ ] Empty ChromaDB → query returns honest "insufficient data" not hallucination
- [ ] Image-only PDF with no OCR → 200 with warning, not crash
- [ ] Grounding score < 0.55 → LOW badge always shown
- [ ] Draft export → PDF always has `%PDF` magic bytes
- [ ] `/health` returns 200 when all services up

---

## Gold QA Eval Set (50 pairs)

Manually annotated question-answer pairs for final evaluation.
Stored at: `eval/gold_qa_pairs.json`

```json
[
  {
    "question":       "What is the TDS rate for professional services under Section 194J?",
    "expected_answer": "10%",
    "source_doc":     "Circular No. 4 of 2023",
    "clause":         "3(c)",
    "entity_type":    "AMOUNT"
  }
]
```

Evaluation script: `eval/evaluate_rag.py`
Metrics: Exact match (for entities), ROUGE-L (for prose answers), citation accuracy.
