# CLAUDE.md — Saarthi-AI Master Project File

> Read this first. All other .md files referenced here.

---

## What Is This

**Saarthi-AI** — Public-sector document intelligence system.
Citizens upload govt/legal docs (IT notices, scheme guidelines). System extracts obligations, deadlines, penalties → answers questions → drafts replies.

New capability: **Agentic RAG + Live Web Search**.
If local corpus insufficient → agent triggers web search on official govt sites → augments answer with live data.

---

## Read Order for LLM

1. `CLAUDE.md` ← you are here
2. `PROJECT_SPEC.md` — full requirements, actors, flows, constraints
3. `ARCHITECTURE.md` — system design, component map, data flow
4. `DATA_PIPELINE.md` — corpus details, chunking strategy, embedding
5. `AGENTIC_RAG.md` — agent loop, tool definitions, web search integration
6. `API_CONTRACT.md` — all endpoints, request/response shapes
7. `SCHEMA.md` — DB schema, vector store structure, metadata fields
8. `TEST_PLAN.md` — unit/integration/E2E test cases
9. `IMPLEMENTATION_NOTES.md` — known gotchas, confirmed-working URLs, env setup

---

## Stack (Final, Non-Negotiable)

| Layer | Tool |
|---|---|
| Frontend | React + TailwindCSS |
| Backend | FastAPI (Python 3.11+) |
| Agent Framework | LangGraph |
| LLM | Mistral-7B-Instruct via Ollama (local) |
| Embeddings | `BAAI/bge-large-en-v1.5` |
| Vector DB | ChromaDB (local persistent) |
| Sparse Retrieval | BM25 via `rank_bm25` |
| Web Search Tool | Tavily API (restricted to govt domains) |
| NER | SpaCy custom trained |
| Clause Classifier | DistilBERT fine-tuned |
| PDF Extraction | pdfplumber + pytesseract OCR fallback |
| DB | PostgreSQL (doc registry, user sessions) |
| Draft Export | WeasyPrint → PDF |
| Containerisation | Docker Compose |

---

## Corpus (Already Collected)

| Collection | Docs | Size | Status |
|---|---|---|---|
| IT Circulars | 337 | 225 MB | Downloaded, needs extraction |
| IT Notifications | 1,778 | 675 MB | Downloaded, needs extraction |
| RBI Circulars | 24 | ~24 MB | Extracted |
| Scheme Docs | 1 (PM-KISAN) | ~1 MB | Extracted |

**Strategy: Use all 1,778 notifications individually. No merging. No subsampling.**
Each doc → chunked at clause level → embedded → stored in ChromaDB with full metadata.

---

## Key Differentiators (Guard These)

1. Agentic loop — LLM decides if retrieval sufficient before answering
2. Live web search fallback — Tavily hits `site:incometaxindia.gov.in` when corpus stale
3. Hybrid retrieval — dense (BGE) + sparse (BM25) + RRF re-ranking
4. Grounding verifier — faithfulness check before every response
5. Source citation — every answer cites exact circular number + date
6. Draft generator — 5 templates filled from extracted entities → PDF export

---

## Scope Lock

**In scope:** IT circulars, IT notifications, RBI circulars, scheme docs (when added)
**Out of scope:** State-level taxes, GST, court judgments, multilingual (future work)
