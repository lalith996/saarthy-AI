# IMPLEMENTATION_NOTES.md — Gotchas + Confirmed Facts

---

## Confirmed Working URLs (as of May 2026)

### RBI — ALWAYS WORKS
```
https://www.rbi.org.in/Scripts/BS_ViewMasterCirculardetails.aspx   # 21 PDF links
https://www.rbi.org.in/Scripts/BS_ViewListofstandalonecirculars.aspx
```
PDFs hosted on `http://rbidocs.rbi.org.in/rdocs/notification/PDFs/*.PDF`
Note: extension is `.PDF` uppercase — use `casefold()` not `.lower()` for matching.

### Income Tax — 2 confirmed live
```
https://www.incometax.gov.in/iec/foportal/sites/default/files/2024-04/Circular%20no%206%20of%202024%20on%20TDS%20TCS.pdf
https://www.incometax.gov.in/iec/foportal/sites/default/files/2022-12/Refer%20Notification.pdf
```
All other IT portal URLs return 503 after initial scraping session — rate limiting.
IT Circulars (337) + Notifications (1778) collected via separate IT website API — already downloaded.

### Schemes — 1 confirmed live
```
https://pmkisan.gov.in/Documents/RevisedPM-KISANOperationalGuidelines(English).pdf
```

---

## Known Dead URLs (Do Not Retry)

```
# All return 503/404 in this environment:
https://nrega.nic.in/*
https://pmjay.gov.in/*
https://pmay-urban.gov.in/*
https://www.pfrda.org.in/*
https://www.meity.gov.in/*
https://incometaxindia.gov.in/communications/*  (CBDT listing pages — 404)
https://dfpd.gov.in/*
https://pmfby.gov.in/*
# Wayback Machine also blocked (403) for these
```

---

## Critical Bug History (Fixed)

| Bug | Root Cause | Fix |
|---|---|---|
| RBI `.PDF` links missed | `.lower()` check missed uppercase `.PDF` | `casefold()` + `has_pdf_extension()` |
| `--max` was per-source | Each scraper had own counter | Shared `global_budget = [n]` mutable list |
| 21 `[skip]` logs per re-run | `download_pdf()` logged skip even for known URLs | Check `existing_urls` before calling `download_pdf()` |
| IT PDF invalid magic bytes | Some URLs serve HTML 503 with 200 status | `is_pdf_content(b"...")` checks `b"%PDF"` prefix |
| Topic detection ordering | "faceless" matched `assessment` before `e_proceedings` | `e_proceedings` rule moved above `assessment` in list |
| `global MAX_PDFS` SyntaxError | `global` declaration after first use in function | Moved to top of `main()` |

---

## Environment Setup

```bash
# Python env (avoid PEP 668)
python3 -m venv .venv
source .venv/bin/activate

# Core deps
pip install requests beautifulsoup4 lxml pdfplumber
pip install fastapi uvicorn[standard]
pip install langchain langgraph
pip install chromadb rank_bm25
pip install sentence-transformers
pip install spacy
pip install tavily-python
pip install weasyprint
pip install psycopg2-binary sqlalchemy

# OCR (requires system packages first)
sudo apt install poppler-utils tesseract-ocr
pip install pdf2image pytesseract

# LLM (local via Ollama)
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull mistral:7b-instruct

# Or use Gemini Flash API (cheaper than OpenAI, long-context)
pip install google-generativeai
```

---

## Corpus File Locations

```
incometax_circulars/
├── metadata.json          # 337 records, has title/url/date/filepath
└── *.pdf                  # 337 PDFs

incometax_notifications/
├── metadata.json          # 1778 records
└── *.pdf                  # 1778 PDFs

saarthi_data/
├── pdfs/
│   ├── rbi/               # 24 RBI circulars
│   ├── income_tax/        # 2 IT docs
│   └── schemes/           # 1 PM-KISAN
├── text/                  # extracted .txt files
└── metadata.json          # 26 records with status/char_count
```

---

## Metadata JSON Schema (IT Collections)

IT circulars and notifications metadata.json may differ from saarthi_data/metadata.json.
Normalise with:

```python
def normalise_record(rec, base_dir):
    file_val = rec.get("file") or rec.get("filepath") or rec.get("path") or ""
    if file_val and not Path(file_val).is_absolute():
        file_val = str(Path(base_dir) / file_val)
    return {
        "title":    rec.get("title") or rec.get("name") or "",
        "url":      rec.get("url") or rec.get("source_url") or "",
        "file":     file_val,
        "date":     rec.get("date") or rec.get("scraped_at") or "",
        "source":   rec.get("source") or str(Path(base_dir).name),
        "doc_type": rec.get("doc_type") or "notification",
    }
```

---

## Chunking Gotchas

- IT notifications often have no numbered clauses — fall back to paragraph splitting
- RBI circulars use "Para X" not numbered — regex must cover `Para \d+`
- Some PDFs extract with garbled Unicode from Hindi/Devanagari headers — strip with `clean_text()`
- Page number artifacts: lines like `"12"` or `"--- 5 ---"` — filter with `re.fullmatch(r"[\d\s\-…]+", ln.strip())`
- Form-feed character `\x0c` appears between pages in pdfplumber output — replace with `\n`

---

## ChromaDB Notes

- Use `PersistentClient` not `EphemeralClient` — data survives restarts
- Collection must be created with `hnsw:space: cosine` — default is L2 which gives wrong similarity scores
- Max batch size for `.add()` = 5000 — batch your 20K chunks in loops of 1000
- ChromaDB doesn't support `$between` for date filtering — use `$gte` + `$lte` separately

---

## Tavily Notes

- Free tier: 1000 searches/month — sufficient for demo/eval
- `search_depth="advanced"` gives full page content, not just snippets
- `include_raw_content=True` needed to get actual text for RAG
- Always restrict with domain filter — without it, returns news/forum garbage
- Tavily returns `published_date` for some results — use as citation date

---

## LangGraph Notes

- `StateGraph` nodes must return full state dict (use `{**state, "key": val}`)
- Conditional edges: function must return string matching keys in `add_conditional_edges` dict
- Use `checkpointer` for conversation memory if adding multi-turn sessions later
- Graph compilation: `app = graph.compile()` — run with `app.invoke(initial_state)`

---

## Performance Benchmarks (Expected)

| Operation | CPU Time | GPU Time |
|---|---|---|
| Extract 1 PDF (pdfplumber) | ~0.5s | same |
| OCR 1 page | ~3s | ~0.5s |
| Embed 1 chunk (BGE-large) | ~0.1s | ~0.01s |
| Embed full corpus (20K chunks) | ~30 min | ~3 min |
| ChromaDB query (top-10) | ~50ms | same |
| BM25 query | ~10ms | same |
| Mistral-7B inference (Q4) | ~5-8s | ~1-2s |
| Full agent loop (no web) | ~8-12s | ~3-5s |
| Full agent loop (with web) | ~12-18s | ~5-8s |

---

## Docker Compose Quick Start

```yaml
# docker-compose.yml
version: "3.9"
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: saarthi
      POSTGRES_USER: saarthi
      POSTGRES_PASSWORD: saarthi
    ports: ["5432:5432"]
    volumes: ["pgdata:/var/lib/postgresql/data"]

  chromadb:
    image: chromadb/chroma:latest
    ports: ["8001:8000"]
    volumes: ["./chroma_store:/chroma/chroma"]

  ollama:
    image: ollama/ollama:latest
    ports: ["11434:11434"]
    volumes: ["ollama_data:/root/.ollama"]

  backend:
    build: ./backend
    ports: ["8000:8000"]
    depends_on: [postgres, chromadb, ollama]
    env_file: .env

  frontend:
    build: ./frontend
    ports: ["3000:3000"]
    depends_on: [backend]

volumes:
  pgdata:
  ollama_data:
```

---

## .env Template

```env
# LLM
OLLAMA_BASE_URL=http://ollama:11434
OLLAMA_MODEL=mistral:7b-instruct

# Vector DB
CHROMA_HOST=chromadb
CHROMA_PORT=8000

# PostgreSQL
DATABASE_URL=postgresql://saarthi:saarthi@postgres:5432/saarthi

# Web Search
TAVILY_API_KEY=tvly-xxxxxxxxxxxxxxxxxxxx

# Embedding
EMBEDDING_MODEL=BAAI/bge-large-en-v1.5

# Grounding thresholds
GROUNDING_HIGH=0.75
GROUNDING_LOW=0.55
WEB_SEARCH_THRESHOLD=0.65
```
