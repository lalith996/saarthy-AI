# PROJECT_SPEC.md — Requirements

---

## Actors

| Actor | Job |
|---|---|
| Citizen | Upload notice, get plain-English explanation + action plan |
| Small Business | Check scheme eligibility, draft compliance reply |
| Legal Assistant | Search across corpus, extract obligations |
| System (Agent) | Orchestrate retrieval, decide web search, verify grounding |

---

## Core Flows

1. **Upload + Analyse** — User uploads PDF → system extracts text → detects doc type → extracts entities (deadline, penalty, authority, recipient) → shows structured summary card
2. **Q&A** — User asks question → agent retrieves chunks → checks confidence → if low: triggers web search → LLM generates grounded answer with citation
3. **Action Plan** — System reasons over extracted obligations → outputs numbered steps with deadlines and risk flags
4. **Draft Generation** — User selects template → LLM fills slots from extracted entities → user edits → exports PDF
5. **Web Search Fallback** — Agent detects query needs data not in corpus (e.g. "latest circular on TDS 2025") → Tavily searches `site:incometaxindia.gov.in` → returns result → agent cites web source

---

## MoSCoW

### Must Have
- PDF upload + text extraction (pdfplumber + OCR fallback)
- Doc type auto-detection (IT circular / notification / RBI / scheme)
- NER: extract Authority, Recipient, Deadline, Monetary Amount, Legal Reference
- Clause classification: OBLIGATION / PROHIBITION / ELIGIBILITY / PENALTY / INFORMATION
- Hybrid RAG (dense + sparse + RRF)
- Grounding verifier (faithfulness check)
- Source citation in every answer
- Web search fallback via Tavily
- 5 draft templates → PDF export
- Agentic loop via LangGraph

### Should Have
- Confidence score display on answers
- Inline entity highlighting on doc view
- Answer history per session
- Hallucination flag (Low/Medium/High confidence badge)

### Won't Have (v1)
- Multilingual support
- Fine-tuned LLM (use instruction-tuned off-shelf)
- User accounts / persistent history across sessions
- State-level tax documents

---

## Constraints

| Dimension | Constraint |
|---|---|
| Latency | Q&A response < 10s (local LLM), < 5s (API LLM) |
| Corpus size | ~2,100 docs, ~900 MB PDFs, ~15-20K chunks in ChromaDB |
| LLM | Must run on 16GB RAM minimum (Mistral-7B Q4) |
| Privacy | No user doc stored beyond session — ephemeral processing |
| Web search | Restricted to whitelist of govt domains only |
| Platform | Web browser (desktop first, mobile responsive) |
| Auth | None for v1 — open access demo |

---

## Evaluation Targets

| Component | Metric | Target |
|---|---|---|
| NER | F1 per entity type | > 0.80 |
| Clause Classifier | Weighted F1 | > 0.85 |
| Retrieval (local) | Hit@3 | > 0.85 |
| RAG Faithfulness | Grounding score | > 0.80 |
| Answer Correctness | Human eval on 50 gold QA pairs | > 0.75 |
| Hallucination Rate | Grounded responses / total | > 0.90 |
| Web Search Precision | Relevant result in top 3 | > 0.80 |
