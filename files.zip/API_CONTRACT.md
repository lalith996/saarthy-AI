# API_CONTRACT.md — FastAPI Endpoints

---

## Base URL
`http://localhost:8000/api/v1`

---

## Endpoints

### POST /upload
Upload + process a PDF document.

**Request:** `multipart/form-data`
```
file: <PDF binary>
```

**Response 200:**
```json
{
  "doc_id": "sha256-hash",
  "doc_type": "IT_CIRCULAR",
  "title": "Circular No. 6 of 2024",
  "date": "2024-04-15",
  "status": "processed",
  "entities": {
    "authority":   "CBDT",
    "recipient":   "All Assessing Officers",
    "deadline":    "2024-06-30",
    "amount":      "₹10,000",
    "legal_ref":   "Section 192"
  },
  "summary": {
    "required_action": "Submit proof of investment",
    "deadline":        "30 June 2024",
    "penalty":         "₹10,000 if ignored",
    "risk":            "Penalty notice u/s 271"
  },
  "chunk_count": 14
}
```

**Response 422:** Validation error (not a PDF / corrupt file)
**Response 415:** Unsupported file type

---

### POST /query
Ask question against corpus + optionally uploaded doc.

**Request:**
```json
{
  "query":       "What is the deadline for submitting Form 12B?",
  "doc_id":      "sha256-hash",    // optional — restrict to one doc
  "doc_type":    "IT_CIRCULAR",    // optional — filter corpus
  "allow_web":   true              // allow Tavily fallback
}
```

**Response 200:**
```json
{
  "answer":           "The deadline for submitting Form 12B is...",
  "confidence":       "HIGH",
  "grounding_score":  0.82,
  "web_used":         false,
  "action_steps": [
    "1. Download Form 12B from incometaxindia.gov.in",
    "2. Submit to employer by 31 March 2024",
    "3. Keep acknowledgment copy"
  ],
  "citations": [
    {
      "title":           "Circular No. 4 of 2023",
      "circular_number": "4/2023",
      "date":            "2023-03-28",
      "url":             "https://incometaxindia.gov.in/...",
      "clause":          "3(b)",
      "source_type":     "local"
    }
  ],
  "latency_ms": 4200
}
```

**Response 200 (LOW confidence):**
```json
{
  "answer":          "Based on available information...",
  "confidence":      "LOW",
  "grounding_score": 0.41,
  "web_used":        true,
  "warning":         "Answer may not be fully grounded. Verify at official portal.",
  "citations": [...]
}
```

---

### POST /analyse
Get full structured analysis of an already-uploaded doc.

**Request:**
```json
{ "doc_id": "sha256-hash" }
```

**Response 200:**
```json
{
  "doc_id":   "sha256-hash",
  "doc_type": "IT_CIRCULAR",
  "entities": { ... },
  "clauses": [
    {
      "clause_number": "3(a)",
      "text":          "The employer shall...",
      "type":          "OBLIGATION",
      "deadline":      "2024-06-30",
      "penalty":       null
    },
    {
      "clause_number": "5",
      "text":          "Failure to comply shall attract...",
      "type":          "PENALTY",
      "deadline":      null,
      "penalty":       "₹10,000"
    }
  ],
  "action_plan": [
    {"step": 1, "action": "Submit Form 12BB", "deadline": "2024-03-31", "risk": "HIGH"},
    {"step": 2, "action": "File revised return", "deadline": "2024-12-31", "risk": "MEDIUM"}
  ]
}
```

---

### POST /draft
Generate a draft document from template + extracted entities.

**Request:**
```json
{
  "doc_id":        "sha256-hash",
  "template_type": "reply_to_notice",
  "user_details": {
    "name":    "Lalith Kumar",
    "pan":     "XXXXX0000X",
    "address": "123, Bengaluru"
  }
}
```

**Template types:** `reply_to_notice` | `appeal_letter` | `scheme_application` | `eligibility_inquiry` | `compliance_confirmation`

**Response 200:**
```json
{
  "draft_id":   "uuid",
  "content":    "To,\nThe Assessing Officer...\n\n[full draft text]",
  "template":   "reply_to_notice",
  "export_url": "/api/v1/draft/uuid/pdf"
}
```

---

### GET /draft/{draft_id}/pdf
Export draft as PDF.

**Response 200:** `application/pdf` binary
**Response 404:** Draft not found

---

### GET /search
Search corpus without agentic loop (direct retrieval).

**Query params:**
```
q=TDS salary 192 deadline
doc_type=IT_CIRCULAR       (optional filter)
top_k=5                    (default 5)
```

**Response 200:**
```json
{
  "results": [
    {
      "chunk_id":        "doc123_3.1",
      "text":            "Clause 3(b): The rate of TDS...",
      "doc_title":       "Circular No. 4 of 2023",
      "date":            "2023-03-28",
      "url":             "https://...",
      "score":           0.87,
      "clause_number":   "3(b)"
    }
  ],
  "total": 5
}
```

---

### GET /health
```json
{
  "status":   "ok",
  "chromadb": "connected",
  "ollama":   "connected",
  "postgres": "connected"
}
```

---

## Error Response Shape (All Endpoints)

```json
{
  "error":   "EXTRACTION_FAILED",
  "message": "Could not extract text from PDF. File may be image-only.",
  "hint":    "Install OCR: pip install pdf2image pytesseract"
}
```

## Common Error Codes

| Code | Meaning |
|---|---|
| `EXTRACTION_FAILED` | pdfplumber + OCR both failed |
| `NOT_A_PDF` | Magic bytes check failed |
| `DOC_NOT_FOUND` | doc_id not in PostgreSQL |
| `LLM_TIMEOUT` | Ollama didn't respond in time |
| `WEB_SEARCH_FAILED` | Tavily API error |
| `LOW_GROUNDING` | Answer confidence below threshold |
